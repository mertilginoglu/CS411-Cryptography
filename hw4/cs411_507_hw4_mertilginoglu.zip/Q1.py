import RSA_OAEP
import random
import requests

API_URL = 'http://cryptlygos.pythonanywhere.com'

my_id = 26774   ## Change this to your ID

endpoint = '{}/{}/{}'.format(API_URL, "RSA_Oracle", my_id )
response = requests.get(endpoint)
c, N, e = 0,0,0
if response.ok:
  res = response.json()
  print(res)
  c, N, e = res['c'], res['N'], res['e']    #get c, N, e
else: print(response.json())

######
a = random.randint(1, N-1)
gcd, _, _ = RSA_OAEP.egcd(a, N)
while (gcd != 1):
  a = random.randint(1, N-1)
  gcd, _, _ = RSA_OAEP.egcd(a, N)

a_inv = RSA_OAEP.modinv(a, N)
c_ = c * pow(a, e, N)

###### Query Oracle it will return corresponding plaintext
endpoint = '{}/{}/{}/{}'.format(API_URL, "RSA_Oracle_query", my_id, c_)
response = requests.get(endpoint)
if(response.ok): m_ = (response.json()['m_'])
else:print(response)

####

res = (m_ * a_inv) % N
res = res.to_bytes(res.bit_length()//8 + 1, byteorder = 'big')
print("Message is:", res)
###Send your answer to the server.
endpoint = '{}/{}/{}/{}'.format(API_URL, "RSA_Oracle_checker", my_id, res)
response = requests.put(endpoint)
print(response.json())