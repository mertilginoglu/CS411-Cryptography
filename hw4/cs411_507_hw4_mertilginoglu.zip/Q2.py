import math
import random
import sympy
import requests
import RSA_OAEP

API_URL = 'http://cryptlygos.pythonanywhere.com'

my_id = 26774  # Change this to your ID

endpoint = '{}/{}/{}'.format(API_URL, "RSA_OAEP", my_id)
response = requests.get(endpoint)
c, N, e = 0, 0, 0
if response.ok:
    res = response.json()
    print(res)
    c, N, e = res['c'], res['N'], res['e']  ##get c, N, e
else:
    print(response.json())

########

for i in range(0, 10000):
    for j in range(127, 256):

        result = RSA_OAEP.RSA_OAEP_Enc(i, e, N, j)
        if result == c:
            print(j)
            PIN_ = i
            break

print(PIN_)
########

# Client sends PIN_ to server
endpoint = '{}/{}/{}/{}'.format(API_URL, "RSA_OAEP", my_id, PIN_)
response = requests.put(endpoint)
print(response.json())